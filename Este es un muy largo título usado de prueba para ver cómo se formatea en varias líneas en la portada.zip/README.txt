Platilla para la elaboración de la memoria de los TFGs elaborados
en le ETSE-UV.

Se proporciona un ejemplo de uso de esta plantilla.

Contenido:

  - Plantilla: tfg.cls (no es necesario editar este fichero)
  
  - Ejemplo de uso de la plantilla: ejemplo-memoria.tex  (hay que editar
    este fichero para poner: autor/a, tutor/a/es, título, convocatoria,
    titulación,  resumen, agradecimientos, etc).
    
  - Directorio para los ficheros de los capítulos: tex (hay que editar
    los ficheros de este directorio)
    
  - Directorio para las figuras: figs (no se debe cambiar el nombre),
    se pueden almacenar las figuras en formato pdf, png o jpg en este
    directorio.
  
  - Directorio para la bibliografía: bib (no se debe cambiar el nombre,
    hay que añadir elementos al fichero bibliografia.bib)


Este material ha sido elaborado por Juan Gutiérrez-Aguado
y se distribuye bajo una licencia Creative Commons:

https://creativecommons.org/licenses/by-nc/4.0/